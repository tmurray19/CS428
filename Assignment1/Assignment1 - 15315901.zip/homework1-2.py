# Assignment 1 - Question 2

#Student ID: 15315901
#Name: Taidgh Murray
#CS428/MA500 Homework 1

"""
Gonna level with you here, I've attended all but two lectures so far, and I still have no idea
what's going on in this subject. Even using packages, I can't really get the answer I need for
the assignment.
"""

import math
import pylab
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit, leastsq
from scipy.stats import t

# Defining data as np arrays
Xi1=np.array([7, 18, 5, 14, 11, 5, 23, 9, 16, 5])
Xi2=np.array([5.11, 16.70, 3.20, 7.00, 11.00, 4.00, 22.10, 7.00, 10.60, 4.80])
Yi=np.array([58, 152, 41, 93, 101, 38, 203, 78, 117, 44])
b0=np.array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0])

# Model definition
def model(Beta, Xi1, Xi2, Error, i):
    return Beta[0] + Beta[1]*Xi1[i] + Beta[2]*Xi2[i] + Error[i]

# Defining the least square estimator
def leastSquareEstimator(b,x, x2):
    return b[0] + b[1]*x[1] + b[2]*x2[2]

# Defining the least square estimator
def func(x, x2, a, b, c):
    return a + b*x + c*x2


# Calculating the b0, b1 & b2 values


# T value with 12 degrees of freedom & a significange level of 0.05
T = t.ppf(0.975, 12)
P = 3

#MSR = (1/p-1)(yTranspose*y - bTranspose * xTranspose * y)


# Defining yHat - The fitted value
def yHat(i):
    return b0[0] + b0[1]*Xi1[i]

# Defining yMean - The sample mean
yTotal = 0

for i in Yi:
    yTotal += i

yMean = (1/len(Yi))*(yTotal)

# Defining SSTO - The Total Sum of Squares
SSTO = 0
for i in Yi:
    SSTO += (i - yMean)**2

# Defining SSE - The Error Sum of Squares
SSE = 0
count = 0
for j in Yi:
    SSE += (j - float(yHat(count)))**2
    count+=1

# Defining SSR - The Regression Sum of Squares
count = 0
SSR = 0
for k in Yi:
    SSR += (float(yHat(count)) - yMean)**2
    count+=1

# Defining MSR
MSR = (1/P-1) * (Yi.transpose()*Yi - b0.transpose()*Xi1.transpose()*Yi)

MSE = SSE/len(Yi)-P
print(MSE)

FStar = MSR/MSE
print(FStar)
